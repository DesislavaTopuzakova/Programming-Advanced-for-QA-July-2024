﻿using System;
namespace Zoo
{
	//описва всяко едно влечуго
	public class Reptile : Animal
	{
        //наследено поле: name
        //наследено пропърти: Name

        //конструктор
        public Reptile(string name) : base(name)
        {
            //нов празен обект
            //name = null

        }
    }
}

