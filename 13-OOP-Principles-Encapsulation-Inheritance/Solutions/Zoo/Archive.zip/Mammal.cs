﻿using System;
namespace Zoo
{
	//описва всеки един бозайник
	public class Mammal : Animal
	{
		//наследено поле: name
		//наследено пропърти: Name

		//конструктор
		public Mammal (string name) : base(name)
		{
			//нов празен обект
			//name = null

		}
	}
}

