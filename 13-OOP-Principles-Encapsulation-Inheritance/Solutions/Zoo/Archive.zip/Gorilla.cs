﻿using System;
namespace Zoo
{
	public class Gorilla : Mammal
	{
		//наследено поле: name
		//наследено пропърти: Name

		public Gorilla (string name) : base(name)
		{
			//нов празен обект
			//name = null
		}
	}
}

