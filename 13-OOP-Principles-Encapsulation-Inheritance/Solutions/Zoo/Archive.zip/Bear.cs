﻿using System;
namespace Zoo
{
	public class Bear : Mammal
	{
        //наследено поле: name
        //наследено пропърти: Name

        public Bear(string name) : base(name)
        {
            //нов празен обект
            //name = null
        }
    }
}

