﻿using System;
namespace Zoo
{
	public class Snake : Reptile
	{
        //наследено поле: name
        //наследено пропърти: Name

        public Snake(string name) : base(name)
        {
            //нов празен обект
            //name = null
        }
    }
}

