﻿namespace CarManufacturer
{
    public class Tire
    {
        //характеристики
        public int Year { get; set; }
        public double Pressure { get; set; }

        //конструктор
        public Tire(int year, double pressure)
        {
            //нов празен обект
            Year = year;
            Pressure = pressure;
        }
    }
}

