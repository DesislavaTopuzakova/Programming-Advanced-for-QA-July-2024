﻿namespace CarManufacturer
{
    public class Engine
    {
        //характеристики -> конски сили, кубатура
        public int HorsePower { get; set; }
        public double CubicCapacity { get; set; }

        //конструктор
        public Engine(int hp, double cubicCapacity)
        {
            //нов празен обект
            HorsePower = hp;
            CubicCapacity = cubicCapacity;
        }
    }
}

